A feladatokat külön `js` fájlban csináld, ezt neked kell hozzáadni a HTML fájlhoz!

# 1-DonutScrolling (7 pont)

1. A `DonutScrolling.js` fájl már létre van hozva, és benne el van helyezve a kód, ami hozzáadja az oldalunkhoz az elemünket. Adj hozzá az oldalhoz egy olyan funkciót, hogy ez a kördiagram görgetés közben jelezze, a százalékkal, és a körülötte lévő útvonallal, hogy éppen hol járunk az oldalon. A kör útvonalát a `#circlepath` id-val mentsd el, a benne lévő szövegét pedig `#donut-text`-vel.
2. A `#circlepath` elemnek a következő js-kóddal tudsz százalék értéket adni, ahol a percentage változóba az általad kiszámolt oldalon lévő pozíciónk értéket kell megváltoztatnod, ez alapján változtasd a benne lévő százalékértéket is:
```js
    // SVG kördiagramm frissítése
    circle.setAttribute('stroke-dasharray', `${percentage}, 100`);
```
3. Érd el, hogy az eseménykezelőre rakott függvény jóval kevesebbszer fusson le, egy behúzott függvénykönyvtár segítségével!

![](gifs/donutScrolling.gif)

# 2-AttractiveButton (6 pont)

1. Az oldal összes gombját fejleszd fel progresszíven úgy, hogy ha az oldalon odaértünk a görgetésben, és az 100%-ban látszódik, akkor felvillanjon a háttérben az árnyéka, hogy figyelemfelkeltőbb legyen. Ha látszódik, a `boxShadow` értékét állítsd be erre: `#D53768 0px 0px 10px 3px`
2. Amikor kiválasztod az összes gombot, tegyél róla, a `.noshadow` class-val rendelkező elemeket ne választ ki! Használd a `:not()` pszeudo-selectort!
3. Fél másodperc eltelte után állítsd vissza a boxShadow értékét `#D53768 0px 0px 0px 0px`-ra!

![](gifs/attractiveButton.gif)

# 3-FunnyButton  (7 pont)

1. Írj egy olyan egyedi HTML element-et a `HTMLButtonElement`-ből leszármaztatva, ami arrébb viszi a gombunkat, ha rávisszük a kurzort! A második ráhúzásnál az eredeti helyre vigye vissza. A HTML elemeknél azokra az elemekre, amikre rá kell raknod, meg vannak jelölve `is="funny-button"` attribútummal.
2. A `mouseenter` eseménnyel nézd meg, hogy az elem fölé vittük-e a kurzort, ha igen, állítsd át a `position`-t `relative`-ra és a `left` értékét `200px`-re.
3. Oldd meg, hogy második ráhúzásnál állítsa vissza a left értéket 0-ra.
4. Ahhoz, hogy az animáció működjön, az elem stílusában a `transition`-t állítsd `all 0.5s`-re.

![](gifs/funny-button.gif)