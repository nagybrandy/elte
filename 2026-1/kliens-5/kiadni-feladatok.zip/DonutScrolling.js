const donut = `<div class="relative w-16 h-16">
<div class="absolute inset-0 flex items-center justify-center">
    <div id="donut-text" class="text-center text-sm font-bold">50%</div>
</div>
<svg viewBox="0 0 36 36" class="absolute w-full h-full">
    <path class="text-gray-300 stroke-current" fill="none" stroke-width="2" d="M18 2.0845a 15.9155 15.9155 0 0 1 0 31.831a 15.9155 15.9155 0 0 1 0 -31.831" />
    <path id="circlepath" class="text-purple-500 stroke-current" fill="none" stroke-width="2" stroke-dasharray="50, 100" d="M18 2.0845a 15.9155 15.9155 0 0 1 0 31.831a 15.9155 15.9155 0 0 1 0 -31.831" />
</svg>
</div>`
document.querySelector('#donutplace').innerHTML += donut

