import React from 'react';
import { Playlists } from './views/playlists/Playlists';
import { Menu } from './views/layout/Menu';

export function App() {
  return (
    <div className="w-10/12 mx-auto">
            <Menu />
            <Playlists />
    </div>
  );
}