const { Service } = require("feathers-sequelize");

exports.Puzzles = class Puzzles extends Service {};
